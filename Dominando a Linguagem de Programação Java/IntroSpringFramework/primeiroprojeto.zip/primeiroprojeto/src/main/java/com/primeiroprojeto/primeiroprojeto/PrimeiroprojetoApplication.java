package com.primeiroprojeto.primeiroprojeto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrimeiroprojetoApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrimeiroprojetoApplication.class, args);
	}

}
