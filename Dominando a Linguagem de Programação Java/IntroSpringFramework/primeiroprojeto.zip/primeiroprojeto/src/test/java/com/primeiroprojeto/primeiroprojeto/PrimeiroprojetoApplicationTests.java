package com.primeiroprojeto.primeiroprojeto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimeiroprojetoApplicationTests {

	@Test
	void contextLoads() {
	}

}
